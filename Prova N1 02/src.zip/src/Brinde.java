public class Brinde {
    public String nome;
    public int preco;

    public Brinde(String nome, int preco) {
        this.nome = nome;
        this.preco = preco;
    }
    
    
}
